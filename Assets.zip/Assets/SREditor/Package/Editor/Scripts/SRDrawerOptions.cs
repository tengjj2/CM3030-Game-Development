namespace SerializeReferenceEditor.Editor
{
	public class SRDrawerOptions
	{
		public bool WithChild { get; set; }
		public bool ButtonTitle { get; set; }
		public bool DisableExpand { get; set; }
	}
}