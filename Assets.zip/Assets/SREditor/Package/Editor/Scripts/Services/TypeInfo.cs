using System;

namespace SerializeReferenceEditor.Editor
{
    public class TypeInfo
    {
        public Type Type;
        public string Path;
    }
}
