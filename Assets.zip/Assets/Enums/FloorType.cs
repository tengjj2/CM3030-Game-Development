public enum FloorType
{
    Combat,
    Shop,
    Lobby,     
    Boss      // (optional) special combat
}