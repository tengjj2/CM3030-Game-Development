// CombatEndGAs.cs
using UnityEngine;

// Fire when the player dies
public class CombatDefeatGA : GameAction
{
    
 }