using UnityEngine;

public enum CardType { Attack, Block, Skill }

[CreateAssetMenu(fileName = "CardData", menuName = "OfficeRumble/Card")]
public class CardData : ScriptableObject
{
    public string cardName;
    [TextArea] public string description;
    public int cost;
    public CardType type;
    public int value; // damage, block, or other magnitude
    public Sprite artwork;
    public bool exhaust; // if true, does not go to discard/reshuffle this run
}
