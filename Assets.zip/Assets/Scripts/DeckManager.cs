using System.Collections.Generic;
using UnityEngine;

public class DeckManager : MonoBehaviour
{
    public static DeckManager Instance { get; private set; }

    [Header("Deck")]
    public List<CardData> startingDeck = new List<CardData>();

    private List<CardData> drawPile = new List<CardData>();
    private List<CardData> discardPile = new List<CardData>();

    [Header("Hand")]
    public Transform handParent; 
    public GameObject cardPrefab; 
    public int handSize = 5;
    public List<CardView> currentHand = new List<CardView>();

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    public void StartRun()
    {
        drawPile = new List<CardData>(startingDeck);
        discardPile.Clear();
        Shuffle(drawPile);
        DrawCards(handSize);
    }

    public void Shuffle(List<CardData> list)
    {
        for (int i = 0; i < list.Count; i++)
        {
            int r = Random.Range(i, list.Count);
            var tmp = list[i];
            list[i] = list[r];
            list[r] = tmp;
        }
    }

    public void DrawCards(int count)
    {
        for (int i = 0; i < count; i++)
            DrawOne();
    }

    void DrawOne()
    {
        if (drawPile.Count == 0)
        {
            if (discardPile.Count == 0) return;
            drawPile.AddRange(discardPile);
            discardPile.Clear();
            Shuffle(drawPile);
        }

        CardData card = drawPile[0];
        drawPile.RemoveAt(0);

        GameObject go = Instantiate(cardPrefab, handParent);
        CardView cv = go.GetComponent<CardView>();
        cv.Setup(card);
        currentHand.Add(cv);
    }

    public void PlayCard(CardView view)
    {
        if (TurnManager.Instance.CurrentAP < view.cardData.cost)
        {
            Debug.Log("Not enough AP");
            return;
        }

        TurnManager.Instance.UseAP(view.cardData.cost);
        ApplyCardEffect(view.cardData);

        if (!view.cardData.exhaust)
            discardPile.Add(view.cardData);

        currentHand.Remove(view);
        Destroy(view.gameObject);
    }

    void ApplyCardEffect(CardData card)
    {
        if (card.type == CardType.Attack)
        {
            var enemy = FindObjectOfType<Enemy>();
            if (enemy != null) enemy.TakeDamage(card.value);
        }
        else if (card.type == CardType.Block)
        {
            Player.Instance.AddBlock(card.value);
        }
        else
        {
            Debug.Log("Played skill: " + card.cardName);
        }
    }

    public void DiscardHand()
    {
        foreach (var cv in currentHand)
        {
            if (!cv.cardData.exhaust)
                discardPile.Add(cv.cardData);
            Destroy(cv.gameObject);
        }
        currentHand.Clear();
    }
}
