using UnityEngine;
using UnityEngine.UI;
using TMPro; 

public class CardView : MonoBehaviour
{
    public Image artImage;       
    public TMP_Text nameText;   
    public TMP_Text costText;    
    public TMP_Text descText;   
    public Button playButton;    

    [HideInInspector] public CardData cardData;  

    public void Setup(CardData data)
    {
        cardData = data;
        artImage.sprite = data.artwork;
        nameText.text = data.cardName;
        costText.text = data.cost.ToString();
        descText.text = data.description;

        playButton.onClick.RemoveAllListeners();
        playButton.onClick.AddListener(OnClickPlay);
    }

    private void OnClickPlay()
    {
        if (DeckManager.Instance != null)
        {
            DeckManager.Instance.PlayCard(this);
        }
        else
        {
            Debug.LogWarning("DeckManager.Instance is null! Make sure DeckManager singleton is set up.");
        }
    }
}
