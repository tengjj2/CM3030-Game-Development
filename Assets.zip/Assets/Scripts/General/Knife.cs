using UnityEngine;

public class Knife : MonoBehaviour
{
    private void OnEnable()
    {
        //ActionSystem.SubscribeReaction<DrawCardGA>(DrawCardReaction, ReactionTiming.POST);

    }
}
