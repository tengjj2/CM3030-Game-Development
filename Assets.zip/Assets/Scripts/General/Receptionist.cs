using UnityEngine;

public class ReceptionistNPC : MonoBehaviour
{
    [TextArea] public string[] Greeting = {
        "Welcome to the lobby!",
        "Please pick a starting boon to begin your run."
    };
}