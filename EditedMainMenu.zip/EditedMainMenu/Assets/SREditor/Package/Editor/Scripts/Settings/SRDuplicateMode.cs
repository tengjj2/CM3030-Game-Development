namespace SerializeReferenceEditor.Editor.Settings
{

	public enum SRDuplicateMode
    {
		Default,
		Copy,
        Null
    }

}