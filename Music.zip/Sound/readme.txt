All of these sound assets are from Pixabay.

Punch Sound Effects by RuskiCommunist (Freesound).
source link: https://pixabay.com/sound-effects/punch-sound-effects-28649/

Game Over sound effects: KL Peach Game Over III by Lightyeartraxx.
source link: https://pixabay.com/sound-effects/kl-peach-game-over-iii-142453/

Button by Universfield.
source link: https://pixabay.com/sound-effects/button-124476/

Purchase sound effects: Cash Register Purchase by Zott820 (Freesound).
source link: https://pixabay.com/sound-effects/cash-register-purchase-87313/

Card sound effects: card mixing by krnfa (Freesound).
source link: https://pixabay.com/sound-effects/card-mixing-48088/

Trashcan sound effects: Trashcan 1 (1) by niyaveronica (Freesound).
source link: https://pixabay.com/sound-effects/search/trashbin/

Fire sound effects: Fire Sound Effects by Alice_soundz.
source link: https://pixabay.com/sound-effects/fire-sound-effects-224089/

