All of these music assets are from Pixabay.

normal level - Game Gaming Minecraft Background Music by HitsLab.
source link: https://pixabay.com/music/video-games-game-gaming-minecraft-background-music-362185/

Shop level background music - Roblox Minecraft Fortnite Video Game Music by BackgroundMusicForVideos.
source link: https://pixabay.com/music/video-games-roblox-minecraft-fortnite-video-game-music-358426/

Boss level background music - Gaming Game Minecraft Background Music by HitsLab.
source link: https://pixabay.com/music/video-games-gaming-game-minecraft-background-music-278382/