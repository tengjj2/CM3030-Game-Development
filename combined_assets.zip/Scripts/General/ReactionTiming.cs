using UnityEngine;

public enum ReactionTiming
{
    PRE,
    POST
}
