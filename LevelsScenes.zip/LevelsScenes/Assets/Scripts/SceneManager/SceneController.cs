using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelSceneController : MonoBehaviour
{
    public ArrowPositioner arrow;

    public void OnLevelClick()
    {
        if (arrow != null && arrow.levelData != null)
        {
            int currentLevel = arrow.levelData.level;
            string sceneName = "Floor" + currentLevel;

            if (Application.CanStreamedLevelBeLoaded(sceneName))
            {
                SceneManager.LoadScene(sceneName);
            }
            else
            {
                Debug.LogError("Scene " + sceneName + " not found!");
            }
        }
        else
        {
            Debug.LogError("Arrow or LevelData is not assigned!");
        }
    }
}
