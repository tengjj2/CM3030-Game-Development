
public enum StatusEffectType
{
    BLOCK,
    HEAL,
    STRENGTH,
    DEFENCE,
    WEAKEN,
    FRAIL,
    BARRIER,
    THORNS,
    BURN,
    POISON,
    CONFUSE,
    EXHAUST,
    DISCARD,
    ENERGYGAIN,
    ENERGYLOSS
}
