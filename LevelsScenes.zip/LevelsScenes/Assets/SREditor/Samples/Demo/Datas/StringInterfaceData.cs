using System;

namespace Demo
{
	[Serializable]
	public class StringInterfaceData : IData
	{
		public string Value;
	}
}